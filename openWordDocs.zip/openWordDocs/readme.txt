
1. Move the folder (openWordDocs) into the Applications folder

2. You can now run saveOpenDocs.app and openPreviousDocs.app. For convenience, you can drag each of these apps to the dock.