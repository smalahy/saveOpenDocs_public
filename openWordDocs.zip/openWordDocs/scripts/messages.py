import re
import tkinter as tk

allProcesses = []
openFiles = []
recordedFiles = []

## Message box specifications
timeoutDelay = 7000
timeoutDelayError = 30000
boxWidth = 50
boxHeight = 15

recordedFiles = []

class errorBox():
    def __init__(self):
        self.root = tk.Tk()
        self.label = tk.Label(
            text='\nSaveOpenDocs: ERROR\n\n\n' + 'Nothing has been recorded.\n' + '\nYou don\'t have any open docs\n' + 'or you haven\'t saved any open docs.\n\n',
            fg = '#CC0000', 
            font=(None, 25),
            height = boxHeight,
            width = boxWidth
            )
        self.label.pack()
        self.root.after(timeoutDelayError, lambda: self.root.destroy())
        self.root.mainloop()

class successBox():
    def __init__(self):
        
        label_text = '\nSaveOpenDocs\n\n' + 'The following docs have been' + '\nrecorded and can be closed.\n\n\n'

        del openFiles[0]
        for fileI in openFiles:
            # if(re.search("\\.doc", fileI)):
            nameSplit = fileI.split("/")
            nameSplit = nameSplit[len(nameSplit) - 1]
            label_text = label_text + nameSplit + '\n'

        self.root = tk.Tk()
        self.label = tk.Label(
            text=label_text + '\n',
            fg = '#006600', 
            font=(None, 25),
            height = boxHeight,
            width = boxWidth
            )

        self.label.pack()
        self.root.after(timeoutDelay, lambda: self.root.destroy())
        self.root.mainloop()

class openingBox():
    def __init__(self):
        

        label_text = '\nSaveOpenDocs\n\n' + 'Opening previously saved docs:\n\n'

        del recordedFiles[0]
        for fileI in recordedFiles:
            nameSplit = fileI.split("/")
            nameSplit = nameSplit[len(nameSplit) - 1]
            label_text = label_text + nameSplit

        self.root = tk.Tk()
        self.label = tk.Label(
            text=label_text + '\n',
            fg = '#036992', 
            font=(None, 25),
            height = boxHeight,
            width = boxWidth
            )

        self.label.pack()
        self.root.after(timeoutDelay, lambda: self.root.destroy())
        self.root.mainloop()