import psutil
import re
import subprocess
import os
import sys
import datetime
from messages import *

## Adding the current date time to the top of openFiles 
openFiles.append('Open files were saved on: ' + str(datetime.datetime.now()) + '\n')

# Iterate through running processes for Word docs
for i in psutil.process_iter():
    if re.search('Word', str(i.name)):
        out = subprocess.check_output(['lsof', '+p', str(i.pid)])
        allProcesses.append(out)

# # If Word isn't running, then throw an error and exit script
if len(allProcesses) < 1:
    errorBox = errorBox()
    sys.exit()

# There should just be a single item in allProcesses, if not, code will have to be updated
assert len(allProcesses) == 1

# Iterate through the doc to find .doc files
for i in allProcesses[0].splitlines():
    line = str(i)
    if re.search('\\.doc', line):
        filePath = line.split(' /Users')[1]
        filePath = '/Users' + filePath
        filePath = filePath.replace('\'', '')
        openFiles.append(filePath)
        
# If no docs are open, then throw an error and exit script
if len(openFiles) < 2:
    errorBox = errorBox()
    sys.exit()

# Save the file paths of open files
my_dir = os.path.expanduser('~/openDocs')

if not os.path.isdir(my_dir):
    os.mkdir(my_dir)

with open(my_dir + '/Log_recently_opened_files.txt', 'w') as f:
    for item in openFiles:
        if re.search('\\.doc', item):
            item = item.replace(" ", "\\ ")

        f.write(item + '\n')
        
successBox = successBox()