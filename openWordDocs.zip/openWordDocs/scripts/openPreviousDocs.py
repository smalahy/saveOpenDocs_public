#!/usr/bin/env python

import os
from messages import *

my_dir = os.path.expanduser('~/openDocs')

with open(my_dir + '/Log_recently_opened_files.txt', 'r') as f:
    for item in f:
    	newItem = item.replace('\\', '')
    	recordedFiles.append(newItem)

    	if re.search('\\.doc', item):
    		os.system("open " + item)

openingBox = openingBox()
